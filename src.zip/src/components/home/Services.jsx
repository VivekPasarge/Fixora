import ServiceCard from "./ServiceCard";

const services = [
  {
    icon: "🚰",
    title: "Plumbing",
    rating: "4.7",
    description: "Fix leaks, installations and maintenance.",
  },
  {
    icon: "💡",
    title: "Electrical",
    rating: "4.6",
    description: "Wiring, repairs and electrical work.",
  },
  {
    icon: "🔨",
    title: "Carpentry",
    rating: "4.6",
    description: "Furniture repair and wood work.",
  },
  {
    icon: "🧺",
    title: "Appliance Repair",
    rating: "4.7",
    description: "AC, Fridge and Washing Machine.",
  },
  {
    icon: "🖌️",
    title: "Painting",
    rating: "4.5",
    description: "Wall painting and texture design.",
  },
  {
    icon: "🧹",
    title: "Cleaning",
    rating: "4.6",
    description: "Home, kitchen and sofa cleaning.",
  },
];

const Services = () => {
  return (
    <section className="bg-slate-50 py-24">

      <div className="mx-auto max-w-7xl px-6">

        <h2 className="text-center text-5xl font-black text-slate-900">
          Popular{" "}
          <span className="text-blue-600">
            Services
          </span>
        </h2>

        <div className="mx-auto mt-4 h-1 w-24 rounded bg-cyan-500"></div>

        <div className="mt-16 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
          {services.map((service) => (
            <ServiceCard
              key={service.title}
              {...service}
            />
          ))}
        </div>

      </div>

    </section>
  );
};

export default Services;