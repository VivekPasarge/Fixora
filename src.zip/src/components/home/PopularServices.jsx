import { motion } from "framer-motion";
import { FaArrowRight } from "react-icons/fa";

import services from "../../data/services";
import ServiceCard from "./ServiceCard";
//import LiveTrackingCard from "./LiveTrackingCard";
import StatsSection from "./StatsSection";

const PopularServices = () => {
  return (
    <section className="bg-[#f8fafc] py-24">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Heading */}

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <span className="inline-block rounded-full bg-cyan-100 px-5 py-2 text-sm font-semibold text-cyan-700">
            OUR SERVICES
          </span>

          <h2 className="mt-6 text-4xl font-extrabold text-slate-900 lg:text-5xl">
            Popular Home Services
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-500">
            Book trusted professionals for every home service with transparent
            pricing, verified experts and real-time tracking.
          </p>
        </motion.div>

        {/* Content */}

        <div className="mt-20 grid gap-10 lg:grid-cols-[1fr_360px]">
          {/* Service Grid */}

          <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {services.map((service) => (
              <ServiceCard
                key={service.id}
                service={service}
              />
            ))}
          </div>

          {/* Tracking Card */}

        
        </div>

        {/* Button */}

        <div className="mt-14 flex justify-center">
          <button className="inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 px-8 py-4 font-semibold text-white shadow-lg transition-all duration-300 hover:scale-105">
            View All Services
            <FaArrowRight />
          </button>
        </div>

        {/* Statistics */}

        <StatsSection />
      </div>
    </section>
  );
};

export default PopularServices;