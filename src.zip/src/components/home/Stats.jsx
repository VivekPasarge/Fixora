import { FaUsers, FaTools, FaCheckCircle, FaStar } from "react-icons/fa";

const stats = [
  {
    icon: <FaTools />,
    number: "500+",
    title: "Verified Professionals",
  },
  {
    icon: <FaCheckCircle />,
    number: "10K+",
    title: "Completed Services",
  },
  {
    icon: <FaUsers />,
    number: "1,000+",
    title: "Happy Customers",
  },
  {
    icon: <FaStar />,
    number: "4.9★",
    title: "Average Rating",
  },
];

const Stats = () => {
  return (
    <section className="bg-[#050B16] py-24">
      <div className="mx-auto grid max-w-7xl gap-8 px-6 md:grid-cols-2 lg:grid-cols-4">

        {stats.map((item) => (
          <div
            key={item.title}
            className="rounded-3xl border border-white/10 bg-[#0F172A] p-8 text-center transition duration-300 hover:-translate-y-2 hover:border-cyan-400"
          >
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-cyan-500/10 text-4xl text-cyan-400">
              {item.icon}
            </div>

            <h2 className="mt-6 text-5xl font-black text-white">
              {item.number}
            </h2>

            <p className="mt-3 text-slate-400">
              {item.title}
            </p>
          </div>
        ))}

      </div>
    </section>
  );
};

export default Stats;