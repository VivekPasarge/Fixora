import { FaArrowRight, FaStar } from "react-icons/fa";

const ServiceCard = ({
  icon,
  title,
 rating,
  description,
}) => {
  return (
    <div className="group rounded-3xl border border-slate-200 bg-white p-8 shadow-sm transition duration-300 hover:-translate-y-2 hover:shadow-2xl">

      <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-slate-100 text-6xl">
        {icon}
      </div>

      <h3 className="text-2xl font-bold text-slate-800">
        {title}
      </h3>

      <div className="mt-2 flex items-center gap-2 text-yellow-500">
        <FaStar />
        <span className="font-semibold text-slate-700">
          {rating}
        </span>
      </div>

      <p className="mt-4 text-slate-500 leading-7">
        {description}
      </p>

      <button className="mt-6 flex items-center gap-2 font-semibold text-blue-600 transition group-hover:gap-4">
        Book Now
        <FaArrowRight />
      </button>

    </div>
  );
};

export default ServiceCard;