import { FaMapMarkerAlt, FaPhoneAlt, FaStar } from "react-icons/fa";
import technician from "../../assets/hero/technician.png";

const LiveTracking = () => {
  return (
    <section className="bg-[#F8FAFC] py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-6 lg:grid-cols-2">

        {/* Left */}
        <div>
          <span className="rounded-full bg-cyan-100 px-4 py-2 font-semibold text-cyan-700">
            Live Tracking
          </span>

          <h2 className="mt-6 text-5xl font-black text-slate-900">
            Track Your Service
            <span className="block text-cyan-600">
              In Real Time
            </span>
          </h2>

          <p className="mt-6 text-lg leading-8 text-slate-500">
            Know exactly where your technician is. Receive live updates,
            estimated arrival time and service progress directly from the app.
          </p>

          <div className="mt-10 space-y-4">

            <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow">
              <FaMapMarkerAlt className="text-2xl text-cyan-500" />
              <div>
                <h4 className="font-bold">Live GPS Tracking</h4>
                <p className="text-slate-500">
                  Follow technician location.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow">
              <FaPhoneAlt className="text-2xl text-cyan-500" />
              <div>
                <h4 className="font-bold">Instant Contact</h4>
                <p className="text-slate-500">
                  Call or chat with technician.
                </p>
              </div>
            </div>

          </div>
        </div>

        {/* Right */}
        <div className="relative">

          <div className="rounded-[35px] bg-[#08111F] p-8 shadow-2xl">

            <div className="rounded-3xl bg-slate-100 p-6">

              <div className="h-[320px] rounded-2xl bg-gradient-to-br from-cyan-100 to-blue-100 flex items-center justify-center text-slate-500 text-xl">
                Live Map
              </div>

            </div>

            <div className="-mt-12 mx-auto flex w-[90%] items-center gap-4 rounded-3xl bg-white p-5 shadow-xl">

              <img
                src={technician}
                alt=""
                className="h-20 w-20 rounded-full object-cover"
              />

              <div className="flex-1">
                <h3 className="font-bold text-slate-800">
                  Rahul Sharma
                </h3>

                <p className="text-sm text-slate-500">
                  Electrician
                </p>

                <div className="mt-2 flex items-center gap-2 text-yellow-500">
                  <FaStar />
                  4.9 Rating
                </div>
              </div>

              <div className="text-right">
                <p className="text-sm text-slate-500">
                  ETA
                </p>

                <h2 className="text-3xl font-black text-cyan-600">
                  12 min
                </h2>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

export default LiveTracking;