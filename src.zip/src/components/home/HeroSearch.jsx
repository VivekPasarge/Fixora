import { HiOutlineMapPin } from "react-icons/hi2";
import { IoChevronDown } from "react-icons/io5";

const HeroSearch = () => {
  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-2xl">
      <div className="grid lg:grid-cols-[1fr_1fr_170px]">
        {/* Location */}

        <div className="flex h-20 items-center gap-4 border-b border-slate-200 px-6 lg:border-b-0 lg:border-r">
          <HiOutlineMapPin className="text-2xl text-blue-600" />

          <input
            type="text"
            placeholder="Enter your location"
            className="w-full text-lg text-slate-700 outline-none placeholder:text-slate-400"
          />
        </div>

        {/* Service */}

        <div className="flex h-20 items-center justify-between border-b border-slate-200 px-6 lg:border-b-0 lg:border-r">
          <span className="text-lg text-slate-500">
            Select Service
          </span>

          <IoChevronDown className="text-xl text-slate-500" />
        </div>

        {/* Button */}

        <button className="h-20 bg-blue-600 text-lg font-semibold text-white transition hover:bg-blue-700">
          Book Now
        </button>
      </div>
    </div>
  );
};

export default HeroSearch;