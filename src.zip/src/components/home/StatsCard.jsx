import { motion } from "framer-motion";

const StatsCard = ({ icon: Icon, value, label, color }) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ duration: 0.25 }}
      className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition hover:shadow-xl"
    >
      <div
        className={`flex h-16 w-16 items-center justify-center rounded-2xl ${color}`}
      >
        <Icon className="text-3xl" />
      </div>

      <h3 className="mt-5 text-4xl font-bold text-slate-900">
        {value}
      </h3>

      <p className="mt-2 text-slate-500">
        {label}
      </p>
    </motion.div>
  );
};

export default StatsCard;