import { motion } from "framer-motion";
import { FiSearch, FiMapPin } from "react-icons/fi";
import { HiOutlineShieldCheck } from "react-icons/hi";

import technician from "../../assets/hero/technician.png";
import houseBg from "../../assets/hero/house-bg.png";
//import van from "../../assets/hero/van.png";

const Hero = () => {
  return (
    <section className="relative min-h-screen overflow-hidden bg-[#050B16]">
      {/* Background */}
      <img
        src={houseBg}
        alt="House"
        className="absolute inset-0 h-full w-full object-cover opacity-20"
      />

      <div className="absolute inset-0 bg-gradient-to-r from-[#050B16] via-[#07111F]/80 to-[#050B16]/60"></div>

      <div className="relative mx-auto flex min-h-screen max-w-7xl items-center px-6 lg:px-10">
        <div className="grid w-full items-center gap-12 lg:grid-cols-2">

          {/* LEFT */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block rounded-full border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 text-sm font-semibold text-cyan-300">
              Trusted Home Services
            </span>

            <h1 className="mt-6 text-6xl font-black leading-none text-white lg:text-[82px]">
              Book Skilled
              <span className="block bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Professionals
              </span>
              In Minutes
            </h1>

            <p className="mt-8 max-w-xl text-lg leading-8 text-slate-300">
              Find verified electricians, plumbers, carpenters, painters,
              cleaners and more. Fast booking, transparent pricing and trusted
              professionals at your doorstep.
            </p>

            {/* Search */}
            <div className="mt-10 rounded-3xl border border-white/10 bg-[#0F172A]/90 p-3 backdrop-blur-xl shadow-2xl">
              <div className="grid gap-3 lg:grid-cols-3">

                <div className="flex items-center gap-3 rounded-2xl bg-[#111C2D] px-4 py-4">
                  <FiSearch className="text-xl text-cyan-400" />
                  <input
                    type="text"
                    placeholder="Service"
                    className="w-full bg-transparent text-white outline-none placeholder:text-slate-500"
                  />
                </div>

                <div className="flex items-center gap-3 rounded-2xl bg-[#111C2D] px-4 py-4">
                  <FiMapPin className="text-xl text-cyan-400" />
                  <input
                    type="text"
                    placeholder="Location"
                    className="w-full bg-transparent text-white outline-none placeholder:text-slate-500"
                  />
                </div>

                <button className="rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 py-4 font-semibold text-white transition duration-300 hover:scale-105">
                  Search Now
                </button>

              </div>
            </div>

            {/* Features */}
            <div className="mt-10 flex flex-wrap gap-10">

              <div className="flex items-center gap-3">
                <HiOutlineShieldCheck className="text-4xl text-cyan-400" />
                <div>
                  <h4 className="font-semibold text-white">
                    Verified Experts
                  </h4>
                  <p className="text-slate-400">
                    1000+ Professionals
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <HiOutlineShieldCheck className="text-4xl text-cyan-400" />
                <div>
                  <h4 className="font-semibold text-white">
                    24/7 Support
                  </h4>
                  <p className="text-slate-400">
                    Always Available
                  </p>
                </div>
              </div>

            </div>

          </motion.div>

          {/* RIGHT */}
          <div className="relative h-[820px]">

            

            {/* Technician */}
            <img
              src={technician}
              alt="Technician"
              className="absolute bottom-0 left-10 z-20 h-[700px] w-auto object-contain drop-shadow-[0_25px_80px_rgba(0,0,0,0.5)]"
            />

            {/* Rating */}
            <div className="absolute right-0 top-44 z-30 w-[280px] rounded-3xl border border-white/10 bg-[#101A2A]/90 p-6 backdrop-blur-xl shadow-2xl">

              <div className="flex items-center gap-4">

                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-2xl">
                  ⭐
                </div>

                <div>
                  <h3 className="text-5xl font-black text-white">
                    4.9
                  </h3>

                  <p className="text-slate-300">
                    Average Rating
                  </p>
                </div>

              </div>

              <div className="mt-5 h-2 rounded-full bg-slate-700">
                <div className="h-2 w-[92%] rounded-full bg-cyan-400"></div>
              </div>

              <p className="mt-4 text-sm text-slate-400">
                Rated by more than 1,000 happy customers.
              </p>

            </div>

            {/* Badge */}
            <div className="absolute bottom-8 left-28 z-30 rounded-full border border-cyan-500/20 bg-cyan-500/10 px-6 py-3 backdrop-blur-xl">
              <p className="font-semibold text-cyan-300">
                ✔ Verified Professionals
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;