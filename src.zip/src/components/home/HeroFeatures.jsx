import {
  HiShieldCheck,
  HiClock,
} from "react-icons/hi2";

import {
  MdOutlinePayments,
  MdSupportAgent,
} from "react-icons/md";

const features = [
  {
    icon: HiShieldCheck,
    title: "Verified Professionals",
  },
  {
    icon: HiClock,
    title: "On-Time Service",
  },
  {
    icon: MdOutlinePayments,
    title: "Secure Payments",
  },
  {
    icon: MdSupportAgent,
    title: "24/7 Support",
  },
];

const HeroFeatures = () => {
  return (
    <div className="mt-2 flex flex-wrap gap-6 lg:gap-8">
      {features.map((feature) => {
        const Icon = feature.icon;

        return (
          <div
            key={feature.title}
            className="flex items-center gap-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full border border-emerald-500/20 bg-emerald-500/10">
              <Icon className="text-lg text-emerald-400" />
            </div>

            <span className="text-sm font-medium text-slate-300">
              {feature.title}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export default HeroFeatures;