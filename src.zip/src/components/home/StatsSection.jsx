import { motion } from "framer-motion";
import {
  HiOutlineUserGroup,
  HiOutlineClipboardDocumentCheck,
  HiOutlineFaceSmile,
  HiOutlineShieldCheck,
} from "react-icons/hi2";

const stats = [
  {
    id: 1,
    icon: HiOutlineUserGroup,
    value: "500+",
    title: "Verified Professionals",
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 2,
    icon: HiOutlineClipboardDocumentCheck,
    value: "10K+",
    title: "Completed Services",
    color: "bg-green-100 text-green-600",
  },
  {
    id: 3,
    icon: HiOutlineFaceSmile,
    value: "1000+",
    title: "Happy Customers",
    color: "bg-pink-100 text-pink-600",
  },
  {
    id: 4,
    icon: HiOutlineShieldCheck,
    value: "99%",
    title: "Customer Satisfaction",
    color: "bg-yellow-100 text-yellow-600",
  },
];

const StatsSection = () => {
  return (
    <section className="mt-20">
      <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((item, index) => {
          const Icon = item.icon;

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.4,
                delay: index * 0.1,
              }}
              viewport={{ once: true }}
              whileHover={{
                y: -8,
              }}
              className="rounded-3xl border border-slate-200 bg-white p-7 shadow-sm transition-all hover:shadow-xl"
            >
              <div
                className={`flex h-16 w-16 items-center justify-center rounded-2xl ${item.color}`}
              >
                <Icon className="text-3xl" />
              </div>

              <h2 className="mt-6 text-4xl font-extrabold text-slate-900">
                {item.value}
              </h2>

              <p className="mt-2 text-slate-500">
                {item.title}
              </p>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};

export default StatsSection;