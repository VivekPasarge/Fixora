import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { HiOutlineMenuAlt3, HiOutlineX } from "react-icons/hi";
import { motion } from "framer-motion";

import logo from "../../assets/logos/fixora-logo.png";
import navLinks from "../../data/navLinks";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -70 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed top-3 left-0 right-0 z-50 px-4"
    >
      <div
        className={`mx-auto flex h-16 max-w-[1400px] items-center justify-between rounded-full border px-6 transition-all duration-300 ${
          scrolled
            ? "border-white/20 bg-[#07111F]/95 shadow-2xl backdrop-blur-2xl"
            : "border-white/10 bg-[#07111F]/70 backdrop-blur-xl"
        }`}
      >
        {/* Logo */}
        <NavLink to="/" className="flex items-center gap-3">
          <img
            src={logo}
            alt="Fixora"
            className="h-9 w-9 rounded-lg object-cover"
          />

          <div>
            <h1 className="text-xl font-extrabold tracking-wide text-white">
              Fixora
            </h1>

            <p className="hidden text-xs text-slate-400 md:block">
              Smart Home Services
            </p>
          </div>
        </NavLink>

        {/* Desktop Menu */}
        <div className="hidden items-center gap-6 lg:flex">
          {navLinks.map((item) => (
            <NavLink
              key={item.id}
              to={item.path}
              className={({ isActive }) =>
                `transition font-medium ${
                  isActive
                    ? "text-cyan-400"
                    : "text-slate-200 hover:text-cyan-400"
                }`
              }
            >
              {item.title}
            </NavLink>
          ))}
        </div>

        {/* Desktop Buttons */}
        <div className="hidden items-center gap-3 lg:flex">
          <button className="rounded-full border border-cyan-500 px-4 py-2 text-sm font-medium text-cyan-400 transition hover:bg-cyan-500 hover:text-white">
            Become Provider
          </button>

          <button className="rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 px-5 py-2 text-sm font-semibold text-white shadow-lg transition hover:scale-105">
            Login
          </button>
        </div>

        {/* Mobile Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="text-3xl text-white lg:hidden"
        >
          {isOpen ? <HiOutlineX /> : <HiOutlineMenuAlt3 />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="mx-auto mt-3 max-w-[1400px] rounded-3xl border border-white/10 bg-[#07111F]/95 p-6 backdrop-blur-2xl lg:hidden">
          <div className="flex flex-col gap-5">
            {navLinks.map((item) => (
              <NavLink
                key={item.id}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className="font-medium text-slate-200 transition hover:text-cyan-400"
              >
                {item.title}
              </NavLink>
            ))}

            <button className="rounded-full border border-cyan-500 py-3 font-medium text-cyan-400">
              Become Provider
            </button>

            <button className="rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 py-3 font-semibold text-white">
              Login
            </button>
          </div>
        </div>
      )}
    </motion.nav>
  );
};

export default Navbar;