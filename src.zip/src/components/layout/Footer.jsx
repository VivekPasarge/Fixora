import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaTwitter,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-[#050B16] text-slate-300">
      <div className="mx-auto max-w-7xl px-6 py-20">

        <div className="grid gap-12 lg:grid-cols-4">

          {/* Brand */}
          <div>
            <h2 className="text-4xl font-black text-white">
              Fix<span className="text-cyan-400">ora</span>
            </h2>

            <p className="mt-5 leading-7 text-slate-400">
              India's trusted platform for booking verified home service
              professionals quickly and safely.
            </p>

            <div className="mt-6 flex gap-4">

              <div className="rounded-full bg-slate-800 p-3 hover:bg-cyan-500 transition">
                <FaFacebookF />
              </div>

              <div className="rounded-full bg-slate-800 p-3 hover:bg-cyan-500 transition">
                <FaInstagram />
              </div>

              <div className="rounded-full bg-slate-800 p-3 hover:bg-cyan-500 transition">
                <FaLinkedinIn />
              </div>

              <div className="rounded-full bg-slate-800 p-3 hover:bg-cyan-500 transition">
                <FaTwitter />
              </div>

            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="mb-6 text-xl font-bold text-white">
              Services
            </h3>

            <ul className="space-y-3">
              <li>Electrician</li>
              <li>Plumber</li>
              <li>Carpenter</li>
              <li>Painter</li>
              <li>Cleaning</li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="mb-6 text-xl font-bold text-white">
              Company
            </h3>

            <ul className="space-y-3">
              <li>About Us</li>
              <li>Become a Partner</li>
              <li>Privacy Policy</li>
              <li>Terms & Conditions</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-6 text-xl font-bold text-white">
              Contact
            </h3>

            <ul className="space-y-3">
              <li>Bengaluru, Karnataka</li>
              <li>support@fixora.com</li>
              <li>+91 98765 43210</li>
            </ul>
          </div>

        </div>

        <div className="mt-16 border-t border-slate-800 pt-8 text-center text-slate-500">
          © 2026 Fixora. All Rights Reserved.
        </div>

      </div>
    </footer>
  );
};

export default Footer;