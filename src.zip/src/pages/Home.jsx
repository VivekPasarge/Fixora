import Hero from "../components/home/Hero";
//import PopularServices from "../components/home/PopularServices";
import Services from "../components/home/Services";
import Stats from "../components/home/Stats";
import LiveTracking from "../components/home/LiveTracking";
import Footer from "../components/layout/Footer";
const Home = () => {
  return (
   <>
  <Hero />
  <Services />
  <Stats/>
  <LiveTracking/>
  <Footer/>
</>
  );
};

export default Home;